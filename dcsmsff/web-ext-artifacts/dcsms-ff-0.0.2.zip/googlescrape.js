const div = ("<div class='hello'>Hello</div>");
$('.hello').css({
    "cursor": "pointer",
    "position": "fixed",
    "margin": "10px",
    "padding": "10px",
    "top": "100px",
    "z-index": "9999",
    "border-radius": "50px",
    "background": "rgba(255,100,0,0.4)"

});
$(".hello").hover(function() {
    $(this).css({ "background": "rgba(255,0,0,0.4)" })
}).mouseout(function() {
    $(this).css({ "background": "rgba(255,0,0,0.1)" })
})
$('.hello').on('click', function(e) {

})