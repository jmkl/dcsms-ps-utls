browser.contextMenus.create({
    id: "push-to-ps",
    title: "Send to Photoshop",
    contexts: ["image"]
});




browser.contextMenus.onClicked.addListener(async(info, tab) => {

    if (info.menuItemId != "push-to-ps") {
        return;
    }
    const data = JSON.stringify({ link: info.srcUrl });

    var req = new Request("http://localhost:5005", { method: "POST", body: data })
    fetch(req).then(response => {
        console.log(response);
    })





    return info.srcUrl;

});